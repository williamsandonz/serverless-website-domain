'use strict';

exports.main = (event, context, callback) => {
  const cf = event.Records[0].cf;
  const request = cf.request;
  const host = request.headers.host[0].value;
  if (host.indexOf('www.') === -1) {
    const response = {
      status: '302',
      statusDescription: 'Found',
      headers: {
        location: [{
          key: 'Location',
          value: `https://www.${host}`,
        }],
      },
    };
    callback(null, response);
  }
  callback(null, request);
};
